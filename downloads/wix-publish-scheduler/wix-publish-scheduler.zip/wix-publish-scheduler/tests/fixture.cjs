const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const SITE='c744f36a-39aa-49da-9f76-22039d93b477',KEY='test-key-not-a-real-credential',OWNER='owner@example.invalid';
function fixture({configure=true,at='2026-10-31T14:30:00Z'}={}){
 let clock=Date.parse(at),id=0,locked=false,failWrite=false;
 const properties=new Map(),triggers=[],calls=[],mail=[];
 const auth={active:OWNER,effective:OWNER};
 const response={code:204,error:null,onFetch:null};
 const mailResponse={quota:100,error:null,quotaError:null,onSend:null};
 const props={getProperty:k=>properties.get(k)||null,setProperty(k,v){if(k==='WP_STATE'&&failWrite){failWrite=false;throw Error('simulated durable write failure');}properties.set(k,String(v));return this;}};
 const context={Date:new Proxy(Date,{construct:(target,args)=>new target(...(args.length?args:[clock])),get:(target,key)=>key==='now'?()=>clock:Reflect.get(target,key)}),
  PropertiesService:{getScriptProperties:()=>props},Session:{getActiveUser:()=>({getEmail:()=>auth.active}),getEffectiveUser:()=>({getEmail:()=>auth.effective})},
  LockService:{getScriptLock:()=>({waitLock(){if(locked)throw Error('nested lock');locked=true;},releaseLock(){if(!locked)throw Error('unbalanced lock');locked=false;}})},
  Utilities:{getUuid:()=>`00000000-0000-0000-0000-${String(++id).padStart(12,'0')}`,newBlob:text=>({getBytes:()=>Buffer.from(text)})},
  ScriptApp:{getProjectTriggers:()=>[...triggers],newTrigger:handler=>({timeBased(){return this;},everyMinutes(n){if(n!==1)throw Error('unexpected interval');return this;},create(){const trigger={getHandlerFunction:()=>handler};triggers.push(trigger);return trigger;}}),deleteTrigger:trigger=>triggers.splice(triggers.indexOf(trigger),1)},
  UrlFetchApp:{fetch(url,options){if(locked)throw Error('network call held the lock');calls.push({url,options});if(response.onFetch)response.onFetch();if(response.error)throw response.error;return {getResponseCode:()=>response.code};}},
  MailApp:{getRemainingDailyQuota(){if(mailResponse.quotaError)throw mailResponse.quotaError;return mailResponse.quota;},sendEmail(message){if(locked)throw Error('mail call held the lock');if(mailResponse.onSend)mailResponse.onSend();if(mailResponse.error)throw mailResponse.error;mail.push(message);}},
  HtmlService:{createHtmlOutputFromFile:name=>({setTitle(){return this;},addMetaTag(){return this;},name})}
 };
 vm.createContext(context);for(const file of ['Code.gs','Notifications.gs'])vm.runInContext(fs.readFileSync(path.join(__dirname,'../app',file),'utf8'),context);
 context.initializeWixPublisher();
 const settings={site_id:SITE,name:'The Forest Gym',url:'https://example.invalid/',api_key:KEY};
 if(configure)context.savePublisherSettings(settings);
 const input=(overrides={})=>({scheduled_local:'2026-11-01T00:00',label:'11月のHP更新',request_id:'browser-request-number-001',...overrides});
 return {context,properties,triggers,calls,mail,mailResponse,auth,response,settings,input,setNow:value=>{clock=typeof value==='number'?value:Date.parse(value);},failNextWrite:()=>{failWrite=true;},jobs:()=>JSON.parse(properties.get('WP_STATE')).jobs};
}
module.exports={fixture,SITE,KEY,OWNER};
