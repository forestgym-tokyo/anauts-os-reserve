[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$ArchivePath,
  [ValidateSet('success', 'drift', 'wrong-project', 'bad-zip')][string]$Scenario = 'success'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$WixTestRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('wix-update-test-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $WixTestRoot | Out-Null
$WixSourceRoot = Split-Path -Parent $PSScriptRoot
Copy-Item -LiteralPath (Join-Path $WixSourceRoot 'Update-Windows.ps1') -Destination $WixTestRoot
$WixTestProject = Join-Path $WixTestRoot 'google-project'
New-Item -ItemType Directory -Path $WixTestProject | Out-Null
[System.IO.File]::WriteAllText((Join-Path $WixTestProject '.clasp.json'), '{"scriptId":"test-script-id-12345678901234567890","rootDir":"."}')
$global:WixTestCommands = @()
$global:WixTestOpened = @()
$global:WixTestArchive = [System.IO.Path]::GetFullPath($ArchivePath)
$global:WixTestScenario = $Scenario
$global:WixTestFixture = Join-Path $PSScriptRoot 'fixtures/previous-release'

function global:Invoke-WebRequest {
  [CmdletBinding()]
  param([switch]$UseBasicParsing, [string]$Uri, [string]$OutFile)
  if (-not $Uri.StartsWith('https://raw.githubusercontent.com/forestgym-tokyo/anauts-os-reserve/')) { throw 'Unexpected download URL' }
  Copy-Item -LiteralPath $global:WixTestArchive -Destination $OutFile
}
function global:Start-Process { param([string]$FilePath) $global:WixTestOpened += $FilePath }
function global:npx.cmd {
  param([Parameter(ValueFromRemainingArguments = $true)][object[]]$ClaspArguments)
  $WixCommand = [string]$ClaspArguments[2]
  $global:WixTestCommands += $WixCommand
  if ($WixCommand -eq 'pull') {
    Copy-Item -LiteralPath (Join-Path $global:WixTestFixture 'Code.gs') -Destination (Join-Path (Get-Location).Path 'Code.js')
    Copy-Item -LiteralPath (Join-Path $global:WixTestFixture 'Index.html') -Destination (Join-Path (Get-Location).Path 'Index.html')
    $WixLiveManifest = Get-Content -LiteralPath (Join-Path $global:WixTestFixture 'appsscript.json') -Raw | ConvertFrom-Json
    $WixLiveManifest | Add-Member -MemberType NoteProperty -Name webapp -Value @{ access = 'MYSELF'; executeAs = 'USER_DEPLOYING' }
    $WixLiveManifest.oauthScopes += 'https://www.googleapis.com/auth/drive.readonly'
    [System.IO.File]::WriteAllText((Join-Path (Get-Location).Path 'appsscript.json'), ($WixLiveManifest | ConvertTo-Json -Depth 100))
    [System.IO.File]::WriteAllText((Join-Path (Get-Location).Path 'LiveOnly.gs'), '// unrelated live module')
    if ($global:WixTestScenario -eq 'drift') { Add-Content -LiteralPath (Join-Path (Get-Location).Path 'Code.js') -Value '// a manual live edit' }
    if ($global:WixTestScenario -eq 'wrong-project') { [System.IO.File]::WriteAllText((Join-Path (Get-Location).Path 'Code.js'), '// another app') }
  } elseif ($WixCommand -eq 'push') {
    if (-not (Test-Path -LiteralPath 'Notifications.gs')) { throw 'Missing notifications module' }
    if (Test-Path -LiteralPath 'Code.js') { throw 'Duplicate Code module was left behind' }
    if (-not (Test-Path -LiteralPath 'LiveOnly.gs')) { throw 'An unrelated live source file was removed' }
    if ((Get-Content -LiteralPath 'WixNotificationDestination.gs' -Raw) -ne 'var WP_REQUESTED_NOTIFICATION_EMAIL = "notify@example.invalid";') { throw 'Notification destination was not provisioned privately' }
    $WixResultManifest = Get-Content -LiteralPath 'appsscript.json' -Raw | ConvertFrom-Json
    if ($WixResultManifest.webapp.access -ne 'MYSELF') { throw 'Private web app access changed' }
    if ($WixResultManifest.webapp.executeAs -ne 'USER_DEPLOYING') { throw 'Web app identity changed' }
    if ($WixResultManifest.oauthScopes -notcontains 'https://www.googleapis.com/auth/drive.readonly') { throw 'Existing scope was removed' }
    if ($WixResultManifest.oauthScopes -notcontains 'https://www.googleapis.com/auth/script.send_mail') { throw 'Mail scope is missing' }
    $WixConfig = Get-Content -LiteralPath '.clasp.json' -Raw | ConvertFrom-Json
    if ($WixConfig.scriptId -ne 'test-script-id-12345678901234567890') { throw 'A different Google project was selected' }
  } elseif ($WixCommand -ne 'create-version') { throw "Unexpected command: $WixCommand" }
  $global:LASTEXITCODE = 0
}

try {
  $WixHash = (Get-FileHash -LiteralPath $global:WixTestArchive -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($Scenario -eq 'bad-zip') { $WixHash = '0' * 64 }
  $WixFailure = $null
  try {
    & (Join-Path $WixTestRoot 'Update-Windows.ps1') -ReleaseRef ('a' * 40) -ExpectedZipSha256 $WixHash -NotificationEmail 'notify@example.invalid'
  } catch { $WixFailure = $_ }
  if ($Scenario -eq 'success') {
    if ($WixFailure) { throw $WixFailure }
    if (($global:WixTestCommands -join ',') -ne 'pull,create-version,push') { throw 'The safe backup/version/upload sequence changed' }
    if ($global:WixTestOpened.Count -ne 1) { throw 'The Google editor was not opened' }
  } else {
    if (-not $WixFailure) { throw 'An invalid update was not stopped' }
    if ($global:WixTestCommands -contains 'push' -or $global:WixTestCommands -contains 'create-version') { throw 'A rejected update modified the remote project' }
    if ($Scenario -eq 'bad-zip' -and $global:WixTestCommands.Count -ne 0) { throw 'Google was accessed before ZIP integrity verification' }
  }
  Write-Output ('Updater smoke test passed: ' + $Scenario)
} finally {
  Remove-Item -LiteralPath $WixTestRoot -Recurse -Force
}
