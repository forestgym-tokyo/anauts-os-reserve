const {test}=require('node:test'),assert=require('node:assert/strict');
const {fixture,SITE,KEY,OWNER}=require('./fixture.cjs');
const midnight='2026-10-31T15:00:00Z';
test('the scheduled JST midnight is stored as UTC and never publishes before that instant',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());assert.equal(e.jobs()[0].scheduled_at,midnight.replace('Z','.000Z'));
 e.setNow('2026-10-31T14:59:59Z');e.context.runWixPublishWorker_();assert.equal(e.calls.length,0);assert.equal(e.jobs()[0].status,'SCHEDULED');
 e.setNow(midnight);e.context.runWixPublishWorker_();assert.equal(e.calls.length,1);assert.equal(e.jobs()[0].status,'SUCCEEDED');
});
test('official Site Publisher endpoint and site-scoped authorization are used without redirects',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());e.setNow(midnight);e.context.runWixPublishWorker_();
 const call=e.calls[0];assert.equal(call.url,'https://www.wixapis.com/site-publisher/v1/site/publish');assert.equal(call.options.method,'post');assert.equal(call.options.payload,'{}');
 assert.equal(call.options.headers.Authorization,KEY);assert.equal(call.options.headers['wix-site-id'],SITE);assert.equal(call.options.followRedirects,false);assert.equal(call.options.validateHttpsCertificates,true);
});
test('duplicate schedule requests are idempotent and only one active reservation is allowed',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());e.context.createPublishReservation(e.input());assert.equal(e.jobs().length,1);assert.equal(e.triggers.length,1);
 assert.throws(()=>e.context.createPublishReservation(e.input({request_id:'a-different-request-123'})),/1件ずつ/);
 assert.throws(()=>e.context.createPublishReservation(e.input({label:'changed'})),/同じ操作番号/);
});
test('cancellation is durable, removes only this app worker, and never calls Wix',()=>{
 const e=fixture();e.triggers.push({getHandlerFunction:()=> 'unrelatedHandler'});e.context.createPublishReservation(e.input());
 e.context.cancelPublishReservation(e.jobs()[0].id);e.setNow(midnight);e.context.runWixPublishWorker_();assert.equal(e.calls.length,0);assert.equal(e.jobs()[0].status,'CANCELLED');assert.equal(e.triggers.length,1);assert.equal(e.triggers[0].getHandlerFunction(),'unrelatedHandler');
});
test('a new reservation can be made after cancellation with a fresh operation id',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());e.context.cancelPublishReservation(e.jobs()[0].id);
 e.context.createPublishReservation(e.input({request_id:'fresh-operation-123456'}));assert.equal(e.jobs()[0].status,'SCHEDULED');assert.equal(e.jobs().length,2);
});
test('a late trigger within five minutes runs; more than five minutes late expires without publishing',()=>{
 for(const [offset,status,calls] of [[5*60000,'SUCCEEDED',1],[5*60000+1,'EXPIRED',0]]){
  const e=fixture();e.context.createPublishReservation(e.input());e.setNow(Date.parse(midnight)+offset);e.context.runWixPublishWorker_();assert.equal(e.jobs()[0].status,status);assert.equal(e.calls.length,calls);assert.equal(e.triggers.length,0);
 }
});
test('a second worker cannot publish a job claimed by the first worker',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());e.response.onFetch=()=>{assert.equal(e.jobs()[0].status,'RUNNING');e.context.runWixPublishWorker_();assert.throws(()=>e.context.cancelPublishReservation(e.jobs()[0].id),/実行を開始/);};
 e.setNow(midnight);e.context.runWixPublishWorker_();e.context.runWixPublishWorker_();assert.equal(e.calls.length,1);
});
test('a failed durable claim makes no network request',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());e.setNow(midnight);e.failNextWrite();assert.throws(()=>e.context.runWixPublishWorker_(),/durable write/);assert.equal(e.calls.length,0);assert.equal(e.jobs()[0].status,'SCHEDULED');
});
test('a crash after the outbound call never retries and is eventually recorded as unknown',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());e.response.onFetch=()=>e.failNextWrite();e.setNow(midnight);
 assert.throws(()=>e.context.runWixPublishWorker_(),/durable write/);assert.equal(e.jobs()[0].status,'RUNNING');e.context.runWixPublishWorker_();assert.equal(e.calls.length,1);
 e.setNow(Date.parse(midnight)+10*60000);e.context.runWixPublishWorker_();assert.equal(e.jobs()[0].status,'UNKNOWN');assert.equal(e.calls.length,1);assert.equal(e.triggers.length,0);
});
test('permission failures stop and record a useful message without retrying',()=>{
 const e=fixture();e.response.code=403;e.context.createPublishReservation(e.input());e.setNow(midnight);e.context.runWixPublishWorker_();e.context.runWixPublishWorker_();
 assert.equal(e.jobs()[0].status,'FAILED');assert.match(e.jobs()[0].message,/公開権限/);assert.equal(e.calls.length,1);
});
test('server and network failures stay unknown and never cause an automatic second publication',()=>{
 for(const type of [500,408,429,'network']){const e=fixture();if(type==='network')e.response.error=Error('error with '+KEY);else e.response.code=type;
  e.context.createPublishReservation(e.input());e.setNow(midnight);e.context.runWixPublishWorker_();e.context.runWixPublishWorker_();assert.equal(e.jobs()[0].status,'UNKNOWN');assert.equal(e.calls.length,1);assert.ok(!JSON.stringify(e.jobs()).includes(KEY));
 }
});
test('the API key is never returned to the browser in settings, schedule, cancel, or dashboard results',()=>{
 const e=fixture();const results=[e.context.savePublisherSettings({...e.settings,api_key:''}),e.context.createPublishReservation(e.input())];results.push(e.context.cancelPublishReservation(e.jobs()[0].id),e.context.getPublisherDashboard());
 for(const result of results){assert.ok(!JSON.stringify(result).includes(KEY));assert.equal(result.key_configured,true);}
});
test('saved settings do not claim to validate access or publish anything',()=>{const e=fixture({configure:false});e.context.savePublisherSettings(e.settings);assert.equal(e.calls.length,0);assert.equal(e.triggers.length,0);});
test('anonymous and other accounts cannot view, configure, schedule, cancel, or reinitialize the app',()=>{
 const e=fixture();for(const actor of ['', 'other@example.invalid']){e.auth.active=actor;
  for(const fn of [()=>e.context.doGet(),()=>e.context.getPublisherDashboard(),()=>e.context.savePublisherSettings(e.settings),()=>e.context.createPublishReservation(e.input()),()=>e.context.cancelPublishReservation('id'),()=>e.context.initializeWixPublisher()])assert.throws(fn);
 }assert.equal(e.calls.length,0);assert.equal(e.properties.get('WP_OWNER_EMAIL'),OWNER);
});
test('site and API key cannot be changed while a publication is pending or running',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());assert.throws(()=>e.context.savePublisherSettings(e.settings),/予約中/);
 e.response.onFetch=()=>assert.throws(()=>e.context.savePublisherSettings(e.settings),/実行中/);e.setNow(midnight);e.context.runWixPublishWorker_();
});
test('configuration drift prevents publishing to a different site',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());e.properties.set('WP_CONFIG',JSON.stringify({...e.settings,site_id:'12345678-1234-1234-1234-123456789012'}));e.setNow(midnight);e.context.runWixPublishWorker_();assert.equal(e.calls.length,0);assert.equal(e.jobs()[0].status,'FAILED');
});
test('dates are strictly validated in JST including leap days, rollover, and minimum lead time',()=>{
 for(const scheduled_local of ['2026-02-29T12:00','2026-11-31T00:00','2026-11-01T24:01','2026-11-01T00:60','11/1 00:00','2026-10-31T23:30']){const e=fixture();assert.throws(()=>e.context.createPublishReservation(e.input({scheduled_local})));assert.equal(e.triggers.length,0);}
 const e=fixture();assert.equal(e.context.wpParseJst_('2028-02-29T00:00'),Date.parse('2028-02-28T15:00:00Z'));
});
test('missing or invalid credentials and site identifiers cannot be scheduled',()=>{
 const e=fixture({configure:false});assert.throws(()=>e.context.createPublishReservation(e.input()),/接続設定/);
 for(const override of [{site_id:'wrong'},{api_key:'short'},{url:'javascript:alert(1)'}])assert.throws(()=>e.context.savePublisherSettings({...e.settings,...override}));assert.equal(e.calls.length,0);
});
test('multibyte history is bounded below the Apps Script per-property limit',()=>{
 const e=fixture();for(let i=0;i<15;i++){e.context.createPublishReservation(e.input({request_id:'request-number-'+String(i).padStart(6,'0'),label:'緑'.repeat(60)}));e.context.cancelPublishReservation(e.jobs()[0].id);}
 assert.ok(e.jobs().length<=8);assert.ok(Buffer.byteLength(e.properties.get('WP_STATE'),'utf8')<=8000);
});
