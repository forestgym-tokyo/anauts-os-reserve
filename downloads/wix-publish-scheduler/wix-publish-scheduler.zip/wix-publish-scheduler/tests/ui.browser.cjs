const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const {fixture,KEY}=require('./fixture.cjs');
const out=process.env.WIX_SCHEDULER_EVIDENCE||'/tmp/wix-publisher-evidence';fs.mkdirSync(out,{recursive:true});
const html=fs.readFileSync(path.join(__dirname,'../app/Index.html'),'utf8');
const server=http.createServer((_req,res)=>{res.setHeader('Content-Type','text/html;charset=utf-8');res.end(html);});
(async()=>{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port;
 const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||undefined,headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});const errors=[];
 try{
  async function open(width=390,configure=true){
   const e=fixture({configure}),page=await browser.newPage({viewport:{width,height:950},timezoneId:'America/New_York'});
   page.on('pageerror',error=>errors.push(error.message));await page.clock.install({time:new Date('2026-10-31T14:30:00Z')});
   await page.exposeFunction('__rpc',(method,input)=>JSON.parse(JSON.stringify(e.context[method](input))));
   await page.addInitScript(()=>{window.google={script:{run:(function make(success,failure){return new Proxy({},{get(_,key){if(key==='withSuccessHandler')return fn=>make(fn,failure);if(key==='withFailureHandler')return fn=>make(success,fn);return input=>window.__rpc(key,input).then(success,error=>failure({message:error.message}));}});})(()=>{},()=>{})}};});
   await page.route('**/*',route=>route.request().url().startsWith(origin)?route.continue():route.abort());
   await page.goto(origin);await page.locator('#content').waitFor({state:'visible'});return {page,e};
  }
  for(const width of [320,390,768,1280]){
   const {page,e}=await open(width);
   await page.locator('#publishAt').fill('2026-11-01T13:30');assert.equal(await page.locator('#scheduleButton').innerText(),'11月1日13時30分に更新予約');
   await page.locator('#publishAt').fill('2026-11-01T00:00');await page.locator('#label').fill('11月のホームページ更新');
   assert.equal(await page.locator('#scheduleButton').innerText(),'11月1日0時に更新予約');
   assert.equal(await page.getByRole('button',{name:'公開',exact:true}).count(),0);assert.equal(e.calls.length,0);
   await page.screenshot({path:path.join(out,'ready-'+width+'.png'),fullPage:true});
   await page.locator('#scheduleButton').click();await page.waitForFunction(()=>document.querySelector('#activeStatus').textContent==='予約中');
   assert.equal(e.jobs()[0].scheduled_at,'2026-10-31T15:00:00.000Z');assert.ok((await page.locator('#activeBooking').innerText()).includes('00:00'));
   assert.equal(await page.locator('#scheduleButton').isDisabled(),true);assert.equal(await page.locator('#siteId').isDisabled(),true);assert.equal(e.calls.length,0);
   await page.screenshot({path:path.join(out,'scheduled-'+width+'.png'),fullPage:true});
   const layout=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,wide:[...document.querySelectorAll('body *')].filter(e=>e.getBoundingClientRect().right>innerWidth+1).map(e=>({tag:e.tagName,id:e.id,cls:e.className,right:e.getBoundingClientRect().right,width:e.getBoundingClientRect().width})).slice(0,10)}));
   assert.ok(layout.scroll<=width,JSON.stringify(layout));await page.close();
  }
  {const {page,e}=await open();
   await page.locator('#publishAt').fill('2026-11-01T00:00');await page.locator('#label').fill('同じ内容の再予約');await page.locator('#scheduleButton').click();await page.waitForFunction(()=>document.querySelector('#activeStatus').textContent==='予約中');
   await page.getByRole('button',{name:'この更新予約を取り消す'}).click();await page.waitForFunction(()=>document.querySelector('#activeStatus').textContent==='予約なし');assert.equal(e.jobs()[0].status,'CANCELLED');
   await page.locator('#scheduleButton').click();await page.waitForFunction(()=>document.querySelector('#activeStatus').textContent==='予約中');assert.equal(e.jobs().length,2);assert.equal(e.jobs()[0].status,'SCHEDULED');
   e.setNow('2026-10-31T15:00:00Z');e.context.runWixPublishWorker_();await page.locator('#refresh').click();await page.waitForFunction(()=>document.querySelector('#activeStatus').textContent==='予約なし');
   assert.match(await page.locator('#history').innerText(),/公開リクエスト成功/);assert.equal(e.calls.length,1);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
   await page.screenshot({path:path.join(out,'result-mobile.png'),fullPage:true});await page.close();
  }
  {const {page,e}=await open(1280,false);assert.equal(await page.locator('#scheduleButton').isDisabled(),true);assert.equal(await page.locator('#settings').getAttribute('open'),'');
   await page.locator('#settingName').fill('The Forest Gym');await page.locator('#settingUrl').fill(e.settings.url);await page.locator('#siteId').fill(e.settings.site_id);await page.locator('#apiKey').fill(KEY);await page.locator('#saveSettings').click();await page.waitForFunction(()=>document.querySelector('#message').textContent.includes('設定を保存'));
   assert.equal(await page.locator('#apiKey').inputValue(),'');assert.equal(await page.locator('#scheduleButton').isEnabled(),true);assert.ok(!(await page.content()).includes(KEY));assert.equal(e.calls.length,0);
   await page.locator('#publishAt').fill('2026-10-31T23:00');await page.locator('#scheduleButton').click();await page.waitForFunction(()=>document.querySelector('#message').classList.contains('error'));assert.equal(e.jobs().length,0);assert.equal(e.calls.length,0);await page.close();
  }
  assert.deepEqual(errors,[]);console.log(JSON.stringify({status:'passed',widths:[320,390,768,1280],checks:['JST scheduling across browser time zones','schedule and cancel','reschedule identical inputs after cancellation','settings key never redisplayed','successful publication display using simulated Wix','past date validation','no real Wix requests','no browser errors or overflow'],evidence:out}));
 }finally{await browser.close();server.close();}
})().catch(error=>{console.error(error);server.close();process.exitCode=1;});
