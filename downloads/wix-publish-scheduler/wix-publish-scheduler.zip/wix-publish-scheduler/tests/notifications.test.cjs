const {test}=require('node:test'),assert=require('node:assert/strict');
const {fixture,KEY}=require('./fixture.cjs');
const to='notify@example.invalid',midnight='2026-10-31T15:00:00Z';
function enable(e){e.context.saveResultNotificationSettings({enabled:true,email:to});}
function due(e){e.context.createPublishReservation(e.input());e.setNow(midnight);}

test('saving email preferences and a test email never publish or change an existing reservation',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());const before=JSON.stringify(e.jobs());enable(e);
 const result=e.context.sendWixNotificationTest({request_id:'notification-test-000001'});
 assert.equal(e.calls.length,0);assert.equal(e.mail.length,1);assert.equal(e.mail[0].to,to);assert.match(e.mail[0].subject,/テスト/);
 assert.equal(JSON.stringify(e.jobs()),before);assert.equal(result.notifications.last_test.status,'SENT');
 e.context.sendWixNotificationTest({request_id:'notification-test-000001'});assert.equal(e.mail.length,1);
});
test('a successful publish is durably recorded before a single result email is sent',()=>{
 const e=fixture();enable(e);due(e);e.mailResponse.onSend=()=>{
  assert.equal(e.jobs()[0].status,'SUCCEEDED');assert.equal(e.jobs()[0].notification.status,'SENDING');
  e.context.runWixPublishWorker_();
 };
 e.context.runWixPublishWorker_();e.context.runWixPublishWorker_();
 assert.equal(e.calls.length,1);assert.equal(e.mail.length,1);assert.equal(e.mail[0].to,to);assert.match(e.mail[0].subject,/更新処理成功/);
 assert.match(e.mail[0].body,/2026-11-01 00:00:00（日本時間）/);assert.ok(e.mail[0].body.includes(e.jobs()[0].id));
 assert.equal(e.jobs()[0].notification.status,'SENT');assert.equal(e.triggers.length,0);
});
test('publish permission failures and unknown results are notified without a second publish',()=>{
 for(const [code,status,title] of [[403,'FAILED','更新失敗'],[500,'UNKNOWN','更新結果の確認が必要']]){
  const e=fixture();enable(e);e.response.code=code;due(e);e.context.runWixPublishWorker_();e.context.runWixPublishWorker_();
  assert.equal(e.jobs()[0].status,status);assert.equal(e.mail.length,1);assert.equal(e.calls.length,1);assert.ok(e.mail[0].subject.includes(title));
 }
});
test('late expiry sends an unexecuted notice without contacting Wix',()=>{
 const e=fixture();enable(e);due(e);e.setNow('2026-10-31T15:06:00Z');e.context.runWixPublishWorker_();
 assert.equal(e.jobs()[0].status,'EXPIRED');assert.equal(e.calls.length,0);assert.equal(e.mail.length,1);assert.match(e.mail[0].subject,/未実行/);
});
test('publication success is preserved when mail quota is exhausted',()=>{
 const e=fixture();enable(e);e.mailResponse.quota=0;due(e);e.context.runWixPublishWorker_();e.context.runWixPublishWorker_();
 assert.equal(e.jobs()[0].status,'SUCCEEDED');assert.equal(e.jobs()[0].notification.status,'FAILED');assert.equal(e.calls.length,1);assert.equal(e.mail.length,0);assert.equal(e.triggers.length,0);
});
test('missing Google mail authorization fails only the notification',()=>{
 const e=fixture();enable(e);e.mailResponse.quotaError=Error('scope denied');due(e);e.context.runWixPublishWorker_();
 assert.equal(e.jobs()[0].status,'SUCCEEDED');assert.equal(e.jobs()[0].notification.status,'FAILED');assert.match(e.jobs()[0].notification.message,/メール送信を許可/);
 assert.equal(e.calls.length,1);assert.equal(e.mail.length,0);
});
test('mail service errors never retry mail or repeat the publication and never expose secrets',()=>{
 const e=fixture();enable(e);e.mailResponse.error=Error('arbitrary internal detail '+KEY);due(e);e.context.runWixPublishWorker_();e.context.runWixPublishWorker_();
 assert.equal(e.jobs()[0].status,'SUCCEEDED');assert.equal(e.jobs()[0].notification.status,'UNKNOWN');assert.equal(e.calls.length,1);assert.equal(e.mail.length,0);
 assert.ok(!JSON.stringify(e.context.getPublisherDashboard()).includes(KEY));assert.ok(!e.jobs()[0].notification.message.includes('internal detail'));
});
test('a crash after sending mail leaves a durable claim and cannot cause duplicates',()=>{
 const e=fixture();enable(e);due(e);e.mailResponse.onSend=()=>e.failNextWrite();
 assert.throws(()=>e.context.runWixPublishWorker_(),/durable write/);assert.equal(e.mail.length,1);assert.equal(e.jobs()[0].status,'SUCCEEDED');assert.equal(e.jobs()[0].notification.status,'SENDING');
 e.context.runWixPublishWorker_();assert.equal(e.mail.length,1);assert.equal(e.calls.length,1);
 e.setNow('2026-10-31T15:10:01Z');e.context.runWixPublishWorker_();assert.equal(e.jobs()[0].notification.status,'UNKNOWN');assert.equal(e.mail.length,1);assert.equal(e.calls.length,1);assert.equal(e.triggers.length,0);
});
test('a pending mail after a publish crash can be recovered without publishing again',()=>{
 const e=fixture();enable(e);due(e);
 const original=e.context.wpDispatchResultNotifications_;e.context.wpDispatchResultNotifications_=()=>{throw Error('simulated worker interruption');};
 assert.throws(()=>e.context.runWixPublishWorker_(),/worker interruption/);assert.equal(e.jobs()[0].status,'SUCCEEDED');assert.equal(e.jobs()[0].notification.status,'PENDING');assert.equal(e.mail.length,0);
 e.context.wpDispatchResultNotifications_=original;e.context.runWixPublishWorker_();assert.equal(e.calls.length,1);assert.equal(e.mail.length,1);
});
test('an existing pre-upgrade reservation receives notices without resetting credentials or its date',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());const state=JSON.parse(e.properties.get('WP_STATE'));delete state.jobs[0].site_url;e.properties.set('WP_STATE',JSON.stringify(state));
 const saved=e.properties.get('WP_CONFIG'),jobs=e.properties.get('WP_STATE');e.context.initializeWixPublisher();enable(e);
 assert.equal(e.properties.get('WP_KEY')||e.properties.get('WP_API_KEY'),KEY);assert.equal(e.properties.get('WP_CONFIG'),saved);assert.equal(e.properties.get('WP_STATE'),jobs);
 e.setNow(midnight);e.context.runWixPublishWorker_();assert.equal(e.mail.length,1);assert.equal(e.jobs()[0].status,'SUCCEEDED');
});
test('cancellation and historic completed jobs are not retroactively emailed',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());e.context.cancelPublishReservation(e.jobs()[0].id);enable(e);e.context.runWixPublishWorker_();assert.equal(e.mail.length,0);
 const other=fixture();due(other);other.context.runWixPublishWorker_();enable(other);other.context.runWixPublishWorker_();assert.equal(other.mail.length,0);
});
test('turning notifications off skips pending mail without changing the completed publish result',()=>{
 const e=fixture();enable(e);due(e);const original=e.context.wpDispatchResultNotifications_;e.context.wpDispatchResultNotifications_=()=>{};e.context.runWixPublishWorker_();
 e.context.saveResultNotificationSettings({enabled:false,email:to});e.context.wpDispatchResultNotifications_=original;e.context.runWixPublishWorker_();
 assert.equal(e.jobs()[0].status,'SUCCEEDED');assert.equal(e.jobs()[0].notification.status,'SKIPPED');assert.equal(e.calls.length,1);assert.equal(e.mail.length,0);
});
test('email addresses cannot inject additional recipients or mail headers',()=>{
 for(const email of ['first@example.invalid,other@example.invalid','first@example.invalid;other@example.invalid','first@example.invalid\nBcc:other@example.invalid','not-an-address','<first@example.invalid>']){
  const e=fixture();assert.throws(()=>e.context.saveResultNotificationSettings({enabled:true,email}));assert.equal(e.mail.length,0);
 }
});
test('anonymous and other actors cannot change email preferences or send test email',()=>{
 const e=fixture();enable(e);for(const actor of ['', 'other@example.invalid']){e.auth.active=actor;assert.throws(()=>e.context.saveResultNotificationSettings({enabled:true,email:to}));assert.throws(()=>e.context.sendWixNotificationTest({request_id:'notification-test-000001'}));}assert.equal(e.mail.length,0);assert.equal(e.calls.length,0);
});
test('history pruning preserves pending notification records',()=>{
 const e=fixture();const jobs=Array.from({length:10},(_,i)=>({id:String(i),status:'SUCCEEDED',notification:{status:i===9?'PENDING':'SENT',to}}));
 e.context.wpWriteState_({jobs});assert.equal(e.jobs().length,8);assert.ok(e.jobs().some(job=>job.id==='9'&&job.notification.status==='PENDING'));
});
test('owner initialization applies the requested destination without sending or resetting an existing reservation',()=>{
 const e=fixture();e.context.createPublishReservation(e.input());const jobs=e.properties.get('WP_STATE'),key=e.properties.get('WP_API_KEY');
 e.context.WP_REQUESTED_NOTIFICATION_EMAIL=to;e.context.initializeWixPublisher();
 const settings=e.context.getPublisherDashboard().notifications;assert.equal(settings.enabled,true);assert.equal(settings.email,to);
 assert.equal(e.properties.get('WP_STATE'),jobs);assert.equal(e.properties.get('WP_API_KEY'),key);assert.equal(e.calls.length,0);assert.equal(e.mail.length,0);
});
test('repeating initialization preserves later manual notification choices',()=>{
 const e=fixture();e.context.WP_REQUESTED_NOTIFICATION_EMAIL=to;e.context.initializeWixPublisher();
 e.context.saveResultNotificationSettings({enabled:false,email:'different@example.invalid'});e.context.initializeWixPublisher();
 const settings=e.context.getPublisherDashboard().notifications;assert.equal(settings.enabled,false);assert.equal(settings.email,'different@example.invalid');
});
