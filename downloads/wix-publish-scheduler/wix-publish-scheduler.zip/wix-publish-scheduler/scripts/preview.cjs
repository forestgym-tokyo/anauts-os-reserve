// Local UI preview. All Wix operations use the test fixture; no real Wix connection exists here.
const fs=require('node:fs'),path=require('node:path'),http=require('node:http');
const {fixture}=require('../tests/fixture.cjs');
const e=fixture({at:new Date().toISOString()});
const methods=new Set(['getPublisherDashboard','savePublisherSettings','createPublishReservation','cancelPublishReservation','saveResultNotificationSettings','sendWixNotificationTest']);
const bridge=`<div class="preview-banner">画面確認用です。実際のWixへ接続・公開せず、予約もこのプレビュー内だけに保存します。</div><script>
window.google={script:{run:(function make(success,failure){return new Proxy({},{get(_,key){if(key==='withSuccessHandler')return fn=>make(fn,failure);if(key==='withFailureHandler')return fn=>make(success,fn);return input=>fetch('/__rpc',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({method:key,input})}).then(r=>r.json()).then(r=>r.ok?success(r.data):failure({message:r.error})).catch(error=>failure({message:error.message}));}});})(()=>{},()=>{})}};
</script>`;
const html=fs.readFileSync(path.join(__dirname,'../app/Index.html'),'utf8').replace('<body>','<body>'+bridge);
const server=http.createServer(async(req,res)=>{
 res.setHeader('Cache-Control','no-store');
 if(req.method==='GET'&&req.url==='/'){res.setHeader('Content-Type','text/html;charset=utf-8');return res.end(html);}
 if(req.method==='POST'&&req.url==='/__rpc'){
  const expected='http://'+req.headers.host;
  if(req.headers.origin!==expected){res.writeHead(403);return res.end();}
  let body='';for await(const chunk of req){body+=chunk;if(body.length>12000){res.writeHead(413);return res.end();}}
  res.setHeader('Content-Type','application/json;charset=utf-8');
  try{const {method,input}=JSON.parse(body);if(!methods.has(method))throw Error('利用できない操作です。');e.setNow(Date.now());res.end(JSON.stringify({ok:true,data:e.context[method](input)}));}
  catch(error){res.end(JSON.stringify({ok:false,error:error.message}));}return;
 }
 res.writeHead(404);res.end();
});
server.listen(Number(process.env.PORT||8765),'127.0.0.1',()=>console.log('Preview only: http://127.0.0.1:'+server.address().port));
