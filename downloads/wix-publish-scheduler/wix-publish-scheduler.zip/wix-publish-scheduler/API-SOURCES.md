# API仕様の確認記録

確認日：2026年10月31日。

Wixの公式npm SDKをnpmレジストリから取得して確認しました。SDKが提供されていることと、利用者の実サイトで呼出権限があることは区別します。

1. [@wix/sites](https://www.npmjs.com/package/@wix/sites) バージョン1.0.69。
2. 同パッケージが依存する[@wix/auto_sdk_sites_site-actions](https://www.npmjs.com/package/@wix/auto_sdk_sites_site-actions) バージョン1.0.28。

後者の`build/cjs/index.typings.d.ts`に、公開された`publishSite()`があり、次の説明が付いています。

> Publishing a site makes any changes previously saved on the site available on the internet.

APIキー認証では`wix-site-id`ヘッダーを付ける旨、必要権限`METASITE.UPDATE`、FQN `wix.site.v1.SitePublisher.PublishSite`が明記されています。

`build/cjs/meta.js`の公開RESTメタデータから、HTTPメソッド`POST`、ホスト`www.wixapis.com`、プレフィックス`/site-publisher`、パス`/v1/site/publish`を確認しました。

呼出先は`https://www.wixapis.com/site-publisher/v1/site/publish`です。

この調査ではWixの実アカウントへのログイン・公開リクエストは行っていません。
